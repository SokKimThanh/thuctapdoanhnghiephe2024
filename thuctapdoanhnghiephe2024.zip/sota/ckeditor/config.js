// Thay đổi lại đúng tên font mình nhúng trong file fonts.css 
/*CKEDITOR.editorConfig = function( config ) {	
	config.contentsCss = '../assets/css/fonts.css';
	config.font_names = 'RobotoMedium;RobotoRegular;' + config.font_names;
};*/