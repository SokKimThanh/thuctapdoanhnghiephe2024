<?php
echo(md5("maixep"."admin"."abc"));